using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using kyrs.BL;
namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        MyMath myMath = new MyMath();
        [TestMethod]
        public void TestSumm()
        {
            double x = 0.1;
            double e = 0.0001;
            double summ = myMath.Summ(x, e);
            double expected = 0.016;
            Assert.AreEqual(expected, summ, 0.001);
        }
        [TestMethod]
        public void TestCreateA()
        {
            double xMin = 0.3;
            double xMax = 0.5;
            double h = 0.01;
            double e = 0.0001;
            double[] A = myMath.CreateA(xMin, xMax, h, e);
            int count = 0;

            for (double x = xMin; x <= xMax; x += h)
            {
                double expected = myMath.ControlFormula(x);
                Assert.AreEqual(expected, A[count], 0.001);
                count++;
            }
        }
        [TestMethod]
        public void TestSquare()
        {
            double[,] B = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
            double[,] expected = { { 30, 36, 42 }, { 66, 81, 96 }, { 102, 126, 150 } };
            double[,] result = myMath.Square(B, B);
            for (int i = 0; i < B.GetLength(0); i++)
            {
                for (int j = 0; j < B.GetLength(1); j++)
                {
                    Assert.AreEqual(expected[i, j], result[i, j]);
                }
            }
        }
        [TestMethod]
        public void TestCreateC()
        {
            double[] A = { 1, 2, 3 };
            double[,] B = { { 1, 2, 3 },{ 4, 5, 6 },{ 7, 8, 9 } };
            double[] expected = { 468, 576, 684 };
            double[] result = myMath.CreateC(A, B);
            for (int i = 0; i < A.Length; i++)
            {
                Assert.AreEqual(expected[i], result[i]);
            }
        }
        [TestMethod]
        public void TestCoeff()
        {
            double[] C = { 1, 2, 3 };
            double[] X = { 0, 1, 2 };
            double[] result = myMath.Coefficient(X, C);
            double[] expected = { 1, 1, 0 };
            for (int i = 0; i < result.Length; i++)
            {
                Assert.AreEqual(expected[i], result[i]);
            }
        }
        [TestMethod]
        public void TestCreateY()
        {
            double[] C = { 1, 2, 3 };
            double h = 0.1;
            double[] result = myMath.CreateY(C, h);
            Assert.AreEqual(C[1], result[10]);
        }
        [TestMethod]
        public void TestSortY()
        {
            double[] Y = { 12.10, 84.45, 23.98, 15.47, 6.33 };
            double[] expected = { 6.33, 12.10, 15.47, 23.98, 84.45 };
            double[] result = myMath.ArraySort(Y);
            for (int i = 0; i < Y.Length; i++)
            {
                Assert.AreEqual(expected[i], result[i]);
            }
        }
    }
}