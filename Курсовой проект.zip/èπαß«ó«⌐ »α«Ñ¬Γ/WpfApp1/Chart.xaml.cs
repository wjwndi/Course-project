﻿using LiveCharts.Wpf;
using LiveCharts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Diagnostics;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Chart.xaml
    /// </summary>
    public partial class Chart : Window
    {
        double[] arrayY;
        double[] arrayYSort;


        private void main_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
        private void quit_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult Result = MessageBox.Show("Закрыть приложение ?", "", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (Result == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }
        private void info_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Process.Start("help.chm");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        public Chart(double[] ArrayY, double[] SortArrayY)
        {
            InitializeComponent();
            this.arrayY = ArrayY;
            this.arrayYSort = SortArrayY;


            CartesianChart ch = new CartesianChart();
            ch.Series = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "График",
                    Values = new ChartValues<double>(arrayY)
                }
            };
            YGrid.Children.Add(ch);


            CartesianChart ch1 = new CartesianChart();
            ch1.Series = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Отсортированный график",
                    Values = new ChartValues<double>(arrayYSort)
                }
            };
            SortYGrid.Children.Add(ch1);
        }
    }
}
