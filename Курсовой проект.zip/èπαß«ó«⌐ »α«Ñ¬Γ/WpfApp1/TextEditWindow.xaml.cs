﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Windows.Controls.Primitives;
using System.Globalization;
using System.Diagnostics;
using System.Collections;


namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для TextEditWindow.xaml
    /// </summary>
    public partial class TextEditWindow : Window
    {
        double[] arrayY;
        double[] arrayYSort;
        static readonly DependencyProperty ModifiedProperty = DependencyProperty.Register("Modified", typeof(bool), typeof(MainWindow), new PropertyMetadata(false));
        SaveFileDialog saveFileDialog1 = new SaveFileDialog();
        OpenFileDialog openFileDialog1 = new OpenFileDialog();
        
        public TextEditWindow(string Text, double[] ArrayY, double[] SortArrayY)
        {
            InitializeComponent();
            openFileDialog1.Filter = saveFileDialog1.Filter = "Text files (*.txt)|*.txt";
            textBox.Text = Text;
            this.arrayY = ArrayY;
            this.arrayYSort = SortArrayY;
        }
        bool TextSaved()
        {
            if (Modified)
            {
                switch (MessageBox.Show("Сохранить изменения в файле?", "", MessageBoxButton.YesNoCancel, MessageBoxImage.Question))
                {
                    case MessageBoxResult.Yes:
                        save_Executed(null, null);
                        return !Modified;
                    case MessageBoxResult.Cancel:
                        return false;
                }
            }
            return true;
        }
        void SaveToFile(string path)
        {
            File.WriteAllText(path, textBox.Text, Encoding.Default);
            Modified = false;
        }
        bool Modified
        {
            get { return (bool)GetValue(ModifiedProperty); }
            set { SetValue(ModifiedProperty, value); }
        }


        private void main_Click(object sender, RoutedEventArgs e)
        {
            TextSaved();
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
        private void clear_Click(object sender, RoutedEventArgs e)
        {
            textBox.Clear();
        }
        private void open_Click(object sender, RoutedEventArgs e)
        {
            open_Executed(null, null);
        }
        private void save_Click(object sender, RoutedEventArgs e)
        {
            save_Executed(null, null);
        }
        private void quit_Click(object sender, RoutedEventArgs e)
        {
            TextSaved();
            MessageBoxResult Result = MessageBox.Show("Закрыть приложение ?", "", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (Result == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }
        private void info_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Process.Start("help.chm");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void chart_Click(object sender, RoutedEventArgs e)
        {
            TextSaved();
            Chart chart = new Chart(arrayY, arrayYSort);
            chart.Show();
            this.Close();
        }


        private void open_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (TextSaved())
                {
                    openFileDialog1.FileName = "";
                    if (openFileDialog1.ShowDialog() == true)
                    {
                        string path = openFileDialog1.FileName;
                        textBox.Text = File.ReadAllText(path, Encoding.Default);
                        saveFileDialog1.FileName = path;
                        Modified = false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void save_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                string path = saveFileDialog1.FileName;
                if (path == "")
                {
                    saveAs_Executed(null, null);
                }
                else
                {
                    SaveToFile(path);
                    MessageBox.Show("Файл успешно сохранён");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void saveAs_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                var oldPath = saveFileDialog1.FileName;
                saveFileDialog1.FileName = System.IO.Path.GetFileName(oldPath);
                if (saveFileDialog1.ShowDialog() == true)
                {
                    string path = saveFileDialog1.FileName;
                    SaveToFile(path);
                    MessageBox.Show("Файл успешно сохранён");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Modified = true;
        }

        
    }
}
