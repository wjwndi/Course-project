﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using kyrs.BL;
using Microsoft.Win32;
using static System.Net.Mime.MediaTypeNames;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        double[] ArrayA;
        double[,] ArrayB;
        double[] ArrayC;
        double[] ArrayY;
        double[] SortArrayY;
        public string Text;

        MyMath myMath = new MyMath();
        string regKeyName = "Software\\WPFExamples\\WpfApp1";
        public MainWindow()
        {
            InitializeComponent();

            RegistryKey rk = null;
            try
            {
                rk = Registry.CurrentUser.OpenSubKey(regKeyName);
                if (rk != null)
                {
                    xMin.Text = (string)rk.GetValue("xMinText", xMin.Text);
                    xMax.Text = (string)rk.GetValue("xMaxText", xMax.Text);
                    eps.Text = (string)rk.GetValue("epsText", xMax.Text);
                    stepH.Text = (string)rk.GetValue("stepHText", stepH.Text);
                    stepG.Text = (string)rk.GetValue("stepGText", stepG.Text);
                }
            }
            finally
            {
                rk?.Close();
            }

        }


        private void controlExample_Click(object sender, RoutedEventArgs e)
        {
            xMin.Text = "0,1";
            xMax.Text = "0,2";
            eps.Text = "0,001";
            stepH.Text = "0,01";
            stepG.Text = "0,1";
        }
        private void clear_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MessageBoxResult Result = MessageBox.Show("Очистить все значения?", "Очистить?", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (Result == MessageBoxResult.Yes)
                {
                    xMin.IsEnabled = true;
                    xMax.IsEnabled = true;
                    eps.IsEnabled = true;
                    stepH.IsEnabled = true;
                    stepG.IsEnabled = true;

                    xMin.Clear();
                    xMax.Clear();
                    eps.Clear();
                    stepH.Clear();
                    stepG.Clear();
                    Text = "";

                    AList.Items.Clear();
                    controlList.Items.Clear();
                    BDataGrid.Items.Refresh();
                    CList.Items.Clear();
                    YList.Items.Clear();
                    SortYList.Items.Clear();

                    arrA.IsEnabled = false;
                    arrB.IsEnabled = false;
                    arrC.IsEnabled = false;
                    arrY.IsEnabled = false;

                    MessageBox.Show("Все значения очищены!", "", MessageBoxButton.OK);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void doMath_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                if (xMin.Text == "" || xMax.Text == "" || eps.Text == "" || stepH.Text == "" || stepG.Text == "")
                {
                    MessageBox.Show("Пожалуйста заполните все поля!", "Ошибка, не все поля заполнены!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else if (Convert.ToDouble(xMin.Text) >= 1 || Convert.ToDouble(xMax.Text) >= 1)
                {
                    MessageBox.Show("Пожалуйста введите данные меньше 1 с плавающей запятой(,)!", "Ошибка с вводом данных!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {

                    AList.Items.Clear();
                    controlList.Items.Clear();
                    BDataGrid.Items.Refresh();
                    CList.Items.Clear();
                    YList.Items.Clear();
                    SortYList.Items.Clear();

                    xMin.IsEnabled = false;
                    xMax.IsEnabled = false;
                    eps.IsEnabled = false;
                    stepH.IsEnabled = false;
                    stepG.IsEnabled = false;

                    double x1 = Convert.ToDouble(xMin.Text);
                    double x2 = Convert.ToDouble(xMax.Text);
                    double ep = Convert.ToDouble(eps.Text);
                    double h = Convert.ToDouble(stepH.Text);
                    double g = Convert.ToDouble(stepG.Text);

                    ArrayA = myMath.CreateA(x1, x2, h, ep);
                    ArrayB = myMath.CreateB(ArrayA);
                    ArrayC = myMath.CreateC(ArrayA, ArrayB);
                    ArrayY = myMath.CreateY(ArrayC, g);
                    SortArrayY = myMath.ArraySort(ArrayY);

                    FillListView(ArrayA, AList);
                    BDataGrid.ItemsSource = ToDataTable(ArrayB).DefaultView;
                    FillListView(ArrayC, CList);
                    FillListView(ArrayY, YList);
                    FillListView(SortArrayY, SortYList);

                    FillText(x1, x2, ep, h, g, ArrayA, ArrayB, ArrayC, ArrayY, SortArrayY);

                    int count = 0;
                    for (double i = x1; i <= x2; i += h)
                    {
                        controlList.Items.Add($"({count})\t {myMath.ControlFormula(i):f4}");
                        count++;
                    }
                    foreach (TabItem item in tabCtrl.Items)
                    {
                        item.IsEnabled = true;
                    }

                    MessageBox.Show("Все расчёты произведены!", "", MessageBoxButton.OK);
                }
            }
            catch (FormatException)
            {
                xMin.IsEnabled = true;
                xMax.IsEnabled = true;
                eps.IsEnabled = true;
                stepH.IsEnabled = true;
                stepG.IsEnabled = true;
                MessageBox.Show("Пожалуйста введите данные меньше 1 с плавающей запятой(,)!", "Ошибка с вводом данных!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                xMin.IsEnabled = true;
                xMax.IsEnabled = true;
                eps.IsEnabled = true;
                stepH.IsEnabled = true;
                stepG.IsEnabled = true;
                MessageBox.Show(ex.Message);
            }
        }
        private void quit_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult Result = MessageBox.Show("Закрыть приложение ?", "", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (Result == MessageBoxResult.Yes)
            {
                this.Close();
            }
        }
        private void textEdit_Click(object sender, RoutedEventArgs e)
        {
            if (xMin.Text == "" || xMax.Text == "" || eps.Text == "" || stepH.Text == "" || stepG.Text == "" || AList.Items.IsEmpty || BDataGrid.Items.IsEmpty || CList.Items.IsEmpty || YList.Items.IsEmpty || SortYList.Items.IsEmpty)
            {
                MessageBox.Show("Пожалуйста заполните все поля и произведите расчёты!", "Ошибка, не все поля заполнены!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                TextEditWindow textEdit = new TextEditWindow(Text, ArrayY, SortArrayY);
                textEdit.Show();
                this.Close();
            }
        }
        private void info_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Process.Start("help.chm");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void chart_Click(object sender, RoutedEventArgs e)
        {
            if (xMin.Text == "" || xMax.Text == "" || eps.Text == "" || stepH.Text == "" || stepG.Text == "" || AList.Items.IsEmpty || BDataGrid.Items.IsEmpty || CList.Items.IsEmpty || YList.Items.IsEmpty || SortYList.Items.IsEmpty)
            {
                MessageBox.Show("Пожалуйста заполните все поля и произведите расчёты!", "Ошибка, не все поля заполнены!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                Chart chart = new Chart(ArrayY, SortArrayY);
                chart.Show();
                this.Close();
            }
        }


        public void FillListView(double[] array, ListView listView)
        {
            int index = 0;
            foreach (double item in array)
            {
                listView.Items.Add($"({index:f0}) \t {item:f4}");
                index += 1;
            }
        }
        public string FillText(double x1, double x2, double ep, double h, double g, double[] ArrayA, double[,] ArrayB, double[] ArrayC, double[] ArrayY, double[] SortArrayY)
        {
            Text += $"Х начальное = {x1}\n" +
                    $"Х конечное = {x2}\n" +
                    $"Точность e = {ep}\n" +
                    $"Шаг h = {h}\n" +
                    $"Шаг g = {g}\n\n";

            Text += $"Массив А:\n\n";
            for (int i = 0; i < ArrayA.Length; i++)
            {
                Text += $"({i})\t";
                Text += $"{ArrayA[i]:f4}";
                Text += "\n";
            }

            Text += $"\nМассив B:\n\n";
            for (int i = 0; i < ArrayB.GetLength(0); i++)
            {
                for (int j = 0; j < ArrayB.GetLength(1); j++)
                {
                    Text += $"{ArrayB[i, j]:f4}" + "         ";
                }
                Text += "\n";
            }

            Text += $"\nМассив C:\n\n";
            for (int i = 0; i < ArrayC.Length; i++)
            {
                Text += $"({i})\t";
                Text += $"{ArrayC[i]:f4}";
                Text += "\n";
            }
            Text += $"\nМассив Y и Отсортированный массив Y:\n\n";
            for (int i = 0; i < ArrayY.Length; i++)
            {
                Text += $"({i})\t";
                Text += $"{ArrayY[i]:f4}" + "\t\t" + $"{SortArrayY[i]:f4}";
                Text += "\n";
            }
            return Text;
        }
        public static DataTable ToDataTable<T>(T[,] matrix)
        {
            var res = new DataTable();
            for (int i = 0; i < matrix.GetLength(1); i++)
            {
                res.Columns.Add($"[{i}]", typeof(T));
            }

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                var row = res.NewRow();
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    row[j] = $"{matrix[i, j]:f5}";
                }
                res.Rows.Add(row);
            }
            return res;
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            RegistryKey rk = null;
            try
            {
                rk = Registry.CurrentUser.CreateSubKey(regKeyName);
                if (rk == null)
                {
                    return;
                }
                rk.SetValue("xMinText", xMin.Text);
                rk.SetValue("xMaxText", xMax.Text);
                rk.SetValue("epsText", eps.Text);
                rk.SetValue("stepHText", stepH.Text);
                rk.SetValue("stepGText", stepG.Text);
            }
            finally
            {
                rk?.Close();
            }

        }
    }
}
