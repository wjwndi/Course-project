﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kyrs.BL
{
    public class MyMath
    {
        public double[] CreateA(double xmin, double xmax, double h, double e)
        {
            List<double> AList = new List<double>();

            for (double x = xmin; x <= xmax; x += h)
            {
                double temp = Summ(x, e);
                AList.Add(temp);
            }

            double[] A = AList.ToArray();
            return A;
        }
        public double Summ(double x, double e)
        {
            int i = 1;
            double temp = x / 24;
            double Sum = temp * (4 - x);
            do
            {
                i++;
                temp *= -Math.Pow(x, 4) / (4 * i * (4 * i - 1) * (4 * i - 2) * (4 * i - 3));
                Sum += temp * (4 * i - x);

            } while (Math.Abs(temp) > e);
            return Sum;
        }
        public double ControlFormula(double x)
        {
            return (2 - Math.Sin(x) - Math.Cos(x) - Math.Exp(-x)) / (2 * Math.Pow(x, 2));
        }
        public double[,] CreateB(double[] A)
        {
            Random random = new Random();

            double[,] B = new double[A.Length, A.Length];
            for (int i = 0; i < B.GetLength(0); i++)
            {
                for (int j = 0; j < B.GetLength(1); j++)
                {
                    B[i, j] = random.NextDouble();
                }
            }
            return B;
        }
        public double[] CreateC(double[] A, double[,] B)
        {
            double[,] B1 = Square(B, B);
            double[] C = new double[A.Length];

            for (int i = 0; i < B1.GetLength(0); i++)
            {
                for (int j = 0; j < B.GetLength(1); j++)
                {
                    C[i] += B1[j, i] * A[j];
                }
            }
            return C;
        }
        public double[,] Square(double[,] B, double[,] B1)
        {
            double[,] B2 = new double[B.GetLength(0), B1.GetLength(1)];

            for (int i = 0; i < B.GetLength(0); i++)
            {
                for (int j = 0; j < B1.GetLength(1); j++)
                {
                    for (int k = 0; k < B1.GetLength(0); k++)
                    {
                        B2[i, j] += B[i, k] * B1[k, j];
                    }
                }
            }
            return B2;
        }
        public double[] CreateY(double[] C, double h)
        {
            List<double> listY = new List<double>();
            double[] X = new double[C.Length];

            for (int i = 0; i < X.Length; i++)
            {
                X[i] = i;
            }
            double[] coefficient = Coefficient(X, C);
            for (double i = X.Min(); i <= X.Max(); i += h)
            {
                double y = coefficient[0];
                for (int j = 1; j < coefficient.Length; j++)
                {
                    y += coefficient[j] * Math.Pow(i, j);
                }
                listY.Add(y);
            }
            double[] Y = listY.ToArray();
            return Y;
        }
        public double[,] MethodGauss(double[,] Y, double[] C, ref double[] X)
        {
            double max;
            double sum;

            double[] Cnew = new double[C.Length];
            C.CopyTo(Cnew, 0);

            for (int k = 0; k < Y.GetLength(0); k++)
            {
                for (int i = k + 1; i < Y.GetLength(1); i++)
                {
                    max = Y[i, k] / Y[k, k];

                    for (int j = k; j < Y.GetLength(1); j++)
                    {
                        Y[i, j] = Y[i, j] - (max * Y[k, j]);
                    }
                    Cnew[i] = Cnew[i] - max * Cnew[k];
                }
            }

            for (int i = Y.GetLength(0) - 1; i >= 0; i--)
            {
                sum = 0;
                for (int j = i + 1; j < Y.GetLength(0); j++)
                {
                    sum += Y[i, j] * X[j];
                }
                X[i] = (Cnew[i] - sum) / Y[i, i];
            }
            return Y;
        }
        public double[] Coefficient(double[] X, double[] C)
        {
            double[,] Y = new double[X.Length, X.Length];

            for (int i = 0; i < Y.GetLength(0); i++)
            {
                for (int j = 0; j < Y.GetLength(0); j++)
                {
                    if (j == 0)
                    {
                        Y[i, j] = 1;
                    }
                    else if (j == 1)
                    {
                        Y[i, j] = X[i];
                    }
                    else
                    {
                        Y[i, j] = Math.Pow(X[i], j);
                    }

                }
            }
            double[] coefficient = new double[C.Length];
            MethodGauss(Y, C, ref coefficient);
            return coefficient;
        }
        public double[] ArraySort(double[] Y)
        {
            double[] sortY = new double[Y.Length];
            Y.CopyTo(sortY, 0);
            double temp;
            for (int i = 0; i < sortY.Length - 1; i++)
            {
                for (int j = i + 1; j > 0; j--)
                {
                    if (sortY[j - 1] > sortY[j])
                    {
                        temp = sortY[j - 1];
                        sortY[j - 1] = sortY[j];
                        sortY[j] = temp;
                    }
                }
            }
            return sortY;
        }
    }
}
